﻿using System.Text.Json;

using static 專題_食物相剋系統.Form1;

namespace 專題_食物相剋系統
{
    public partial class StatisticsForm : Form
    {
        private FormResizer resizer = new FormResizer();
        private string accountName;

        // 建構子：初始化並載入統計資料
        public StatisticsForm(string account)
        {
            InitializeComponent();
            this.Load += StatisticsForm_Load;
            this.Resize += StatisticsForm_Resize;
            accountName = account;

            LoadRecordsJson();
            LoadMealStatistics();
            LoadFoodStatistics();
            LoadWeekdayStatistics();
            LoadEmptyDays();
        }

        // 表單載入時，記錄原始尺寸供縮放使用
        private void StatisticsForm_Load(object sender, EventArgs e)
        {
            resizer.CaptureOriginal(this);
        }

        // 視窗大小改變時，調整控制項大小
        private void StatisticsForm_Resize(object sender, EventArgs e)
        {
            resizer.ResizeAll(this);
        }

        // 自訂 GroupBox 標題繪製，去除虛線
        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = (GroupBox)sender;
            e.Graphics.Clear(box.BackColor);
            TextRenderer.DrawText(e.Graphics, box.Text, box.Font, new Point(8, 0), box.ForeColor);
        }

        // 載入所有帳號的飲食紀錄（從 JSON 檔）
        private void LoadRecordsJson()
        {
            string path = Path.Combine(Application.StartupPath, "records.json");
            if (File.Exists(path))
            {
                string json = File.ReadAllText(path, System.Text.Encoding.UTF8);
                records = JsonSerializer.Deserialize<Dictionary<string, List<Form1.Record>>>(json);
            }
            else
            {
                records = new Dictionary<string, List<Form1.Record>>();
            }
        }

        // 統計餐別出現次數，顯示於 listBoxMeal
        private void LoadMealStatistics()
        {
            if (!records.ContainsKey(accountName)) return;

            var mealStats = records[accountName]
                .GroupBy(r => r.餐別)
                .ToDictionary(g => g.Key, g => g.Count());

            listBoxMeal.Items.Clear();
            foreach (var item in mealStats)
                listBoxMeal.Items.Add($"{item.Key}：{item.Value} 次");
        }

        // 統計食物出現頻率，顯示於 listBoxFood
        private void LoadFoodStatistics()
        {
            if (!records.ContainsKey(accountName)) return;

            var foodStats = records[accountName]
                .GroupBy(r => r.食物)
                .ToDictionary(g => g.Key, g => g.Count());

            listBoxFood.Items.Clear();
            foreach (var item in foodStats.OrderByDescending(f => f.Value))
                listBoxFood.Items.Add($"{item.Key}：{item.Value} 次");
        }

        // 統計每星期填寫次數，顯示於 listBoxWeekday
        private void LoadWeekdayStatistics()
        {
            if (!records.ContainsKey(accountName)) return;

            var weekdayStats = records[accountName]
                .GroupBy(r => r.星期)
                .ToDictionary(g => g.Key, g => g.Count());

            listBoxWeekday.Items.Clear();

            if (weekdayStats.Count == 0)
            {
                listBoxWeekday.Items.Add("目前無統計資料");
                return;
            }

            string[] weekdayOrder = { "一", "二", "三", "四", "五", "六", "日" };
            foreach (var w in weekdayOrder)
            {
                if (weekdayStats.ContainsKey(w))
                    listBoxWeekday.Items.Add($"星期{w}：{weekdayStats[w]} 次");
            }

            if (listBoxWeekday.Items.Count == 0)
                listBoxWeekday.Items.Add("目前無統計資料");
        }

        // 顯示上週與本週尚未填寫日期，顯示於 listBoxEmptyDays
        private void LoadEmptyDays()
        {
            if (!records.ContainsKey(accountName))
            {
                listBoxEmptyDays.Items.Clear();
                listBoxEmptyDays.Items.Add("找不到帳號紀錄！");
                return;
            }

            var recordedDates = records[accountName]
                .Select(r => r.日期)
                .Distinct()
                .ToHashSet();

            listBoxEmptyDays.Items.Clear();

            DateTime today = DateTime.Today;
            int todayDay = (int)today.DayOfWeek;
            DateTime thisSunday = today.AddDays(-todayDay);    // 本週日
            DateTime lastSunday = thisSunday.AddDays(-7);      // 上週日

            // 從上週日開始連續 14 天，找未填寫日期
            for (int i = 0; i < 14; i++)
            {
                DateTime date = lastSunday.AddDays(i);
                string dateStr = date.ToString("yyyy-MM-dd");

                if (!recordedDates.Contains(dateStr))
                {
                    // 注意強制轉型 DayOfWeek 為 int 作索引
                    string weekday = "日一二三四五六"[(int)date.DayOfWeek].ToString();
                    listBoxEmptyDays.Items.Add($"{dateStr}（星期{weekday}）");
                }
            }

            if (listBoxEmptyDays.Items.Count == 0)
                listBoxEmptyDays.Items.Add("本週與上週都有填寫！");
        }

        // 返回上一視窗
        private void btnBack_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["FoodLogForm"] is Form mainForm)
                mainForm.Show();
            this.Close();
        }

        // 一次呼叫載入所有統計，方便刷新
        private void LoadStatistics()
        {
            LoadMealStatistics();
            LoadFoodStatistics();
            LoadWeekdayStatistics();
            LoadEmptyDays();
        }

        // 按鈕事件：重新載入資料並刷新統計列表
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadRecordsJson();
            LoadStatistics();
        }
    }
}
