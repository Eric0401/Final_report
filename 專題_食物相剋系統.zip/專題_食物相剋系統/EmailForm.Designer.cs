﻿namespace 專題_食物相剋系統
{
    partial class EmailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPrompt = new Label();
            txtEmail = new TextBox();
            btnSend = new Button();
            btnClear = new Button();
            btnBack = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // lblPrompt
            // 
            lblPrompt.AutoSize = true;
            lblPrompt.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblPrompt.Location = new Point(56, 59);
            lblPrompt.Name = "lblPrompt";
            lblPrompt.Size = new Size(230, 21);
            lblPrompt.TabIndex = 0;
            lblPrompt.Text = "請輸入收件者 Email :";
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtEmail.Location = new Point(289, 56);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(314, 33);
            txtEmail.TabIndex = 1;
            // 
            // btnSend
            // 
            btnSend.Dock = DockStyle.Fill;
            btnSend.Font = new Font("標楷體", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnSend.Location = new Point(3, 3);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(176, 41);
            btnSend.TabIndex = 2;
            btnSend.Text = "確認";
            btnSend.UseVisualStyleBackColor = true;
            btnSend.Click += btnSend_Click;
            // 
            // btnClear
            // 
            btnClear.Dock = DockStyle.Fill;
            btnClear.Font = new Font("標楷體", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnClear.Location = new Point(185, 3);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(176, 41);
            btnClear.TabIndex = 3;
            btnClear.Text = "清除";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // btnBack
            // 
            btnBack.Dock = DockStyle.Fill;
            btnBack.Font = new Font("標楷體", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnBack.Location = new Point(367, 3);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(177, 41);
            btnBack.TabIndex = 4;
            btnBack.Text = "返回";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.Controls.Add(btnSend, 0, 0);
            tableLayoutPanel1.Controls.Add(btnBack, 2, 0);
            tableLayoutPanel1.Controls.Add(btnClear, 1, 0);
            tableLayoutPanel1.Location = new Point(56, 115);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(547, 47);
            tableLayoutPanel1.TabIndex = 5;
            // 
            // EmailForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(664, 211);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(txtEmail);
            Controls.Add(lblPrompt);
            Name = "EmailForm";
            Text = "收件者帳號";
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPrompt;
        private TextBox txtEmail;
        private Button btnSend;
        private Button btnClear;
        private Button btnBack;
        private TableLayoutPanel tableLayoutPanel1;
    }
}