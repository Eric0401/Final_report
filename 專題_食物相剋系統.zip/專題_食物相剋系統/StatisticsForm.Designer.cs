﻿namespace 專題_食物相剋系統
{
    partial class StatisticsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            groupBox4 = new GroupBox();
            listBoxEmptyDays = new ListBox();
            groupBox3 = new GroupBox();
            listBoxWeekday = new ListBox();
            groupBox2 = new GroupBox();
            listBoxFood = new ListBox();
            groupBox1 = new GroupBox();
            listBoxMeal = new ListBox();
            btnBack = new Button();
            btnRefresh = new Button();
            tableLayoutPanel1.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(groupBox4, 1, 1);
            tableLayoutPanel1.Controls.Add(groupBox3, 0, 1);
            tableLayoutPanel1.Controls.Add(groupBox2, 1, 0);
            tableLayoutPanel1.Controls.Add(groupBox1, 0, 0);
            tableLayoutPanel1.Controls.Add(btnBack, 0, 2);
            tableLayoutPanel1.Controls.Add(btnRefresh, 1, 2);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 3;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 25F));
            tableLayoutPanel1.Size = new Size(984, 561);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(listBoxEmptyDays);
            groupBox4.Dock = DockStyle.Fill;
            groupBox4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            groupBox4.Location = new Point(495, 271);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(486, 262);
            groupBox4.TabIndex = 3;
            groupBox4.TabStop = false;
            groupBox4.Text = "空白日期";
            // 
            // listBoxEmptyDays
            // 
            listBoxEmptyDays.Dock = DockStyle.Fill;
            listBoxEmptyDays.FormattingEnabled = true;
            listBoxEmptyDays.ItemHeight = 20;
            listBoxEmptyDays.Location = new Point(3, 24);
            listBoxEmptyDays.Name = "listBoxEmptyDays";
            listBoxEmptyDays.ScrollAlwaysVisible = true;
            listBoxEmptyDays.Size = new Size(480, 235);
            listBoxEmptyDays.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(listBoxWeekday);
            groupBox3.Dock = DockStyle.Fill;
            groupBox3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            groupBox3.Location = new Point(3, 271);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(486, 262);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "\t星期幾出現次數";
            // 
            // listBoxWeekday
            // 
            listBoxWeekday.Dock = DockStyle.Fill;
            listBoxWeekday.FormattingEnabled = true;
            listBoxWeekday.ItemHeight = 20;
            listBoxWeekday.Location = new Point(3, 24);
            listBoxWeekday.Name = "listBoxWeekday";
            listBoxWeekday.ScrollAlwaysVisible = true;
            listBoxWeekday.Size = new Size(480, 235);
            listBoxWeekday.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(listBoxFood);
            groupBox2.Dock = DockStyle.Fill;
            groupBox2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            groupBox2.Location = new Point(495, 3);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(486, 262);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "食物出現次數";
            // 
            // listBoxFood
            // 
            listBoxFood.Dock = DockStyle.Fill;
            listBoxFood.FormattingEnabled = true;
            listBoxFood.ItemHeight = 20;
            listBoxFood.Location = new Point(3, 24);
            listBoxFood.Name = "listBoxFood";
            listBoxFood.ScrollAlwaysVisible = true;
            listBoxFood.Size = new Size(480, 235);
            listBoxFood.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(listBoxMeal);
            groupBox1.Dock = DockStyle.Fill;
            groupBox1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            groupBox1.Location = new Point(3, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(486, 262);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "餐別統計";
            groupBox1.Paint += groupBox1_Paint;
            // 
            // listBoxMeal
            // 
            listBoxMeal.Dock = DockStyle.Fill;
            listBoxMeal.FormattingEnabled = true;
            listBoxMeal.ItemHeight = 20;
            listBoxMeal.Location = new Point(3, 24);
            listBoxMeal.Name = "listBoxMeal";
            listBoxMeal.ScrollAlwaysVisible = true;
            listBoxMeal.Size = new Size(480, 235);
            listBoxMeal.TabIndex = 0;
            // 
            // btnBack
            // 
            btnBack.Dock = DockStyle.Fill;
            btnBack.Location = new Point(0, 536);
            btnBack.Margin = new Padding(0);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(492, 25);
            btnBack.TabIndex = 4;
            btnBack.Text = "返回";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // btnRefresh
            // 
            btnRefresh.Dock = DockStyle.Fill;
            btnRefresh.Location = new Point(492, 536);
            btnRefresh.Margin = new Padding(0);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(492, 25);
            btnRefresh.TabIndex = 5;
            btnRefresh.Text = "重新整理";
            btnRefresh.UseVisualStyleBackColor = true;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // StatisticsForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(984, 561);
            Controls.Add(tableLayoutPanel1);
            Name = "StatisticsForm";
            Text = "飲食統計";
            Load += StatisticsForm_Load;
            tableLayoutPanel1.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private GroupBox groupBox1;
        private GroupBox groupBox4;
        private ListBox listBoxEmptyDays;
        private GroupBox groupBox3;
        private ListBox listBoxWeekday;
        private GroupBox groupBox2;
        private ListBox listBoxFood;
        private ListBox listBoxMeal;
        private Button btnBack;
        private Button btnRefresh;
    }
}