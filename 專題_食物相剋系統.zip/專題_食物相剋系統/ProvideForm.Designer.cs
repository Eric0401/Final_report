﻿namespace 專題_食物相剋系統
{
    partial class ProvideForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProvideForm));
            tableLayoutPanel1 = new TableLayoutPanel();
            txtFood = new TextBox();
            txtSolution = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label2 = new Label();
            txtConflict = new TextBox();
            txtAdvantage = new TextBox();
            label3 = new Label();
            label1 = new Label();
            txtConsequence = new TextBox();
            buttonBack = new Button();
            tableLayoutPanel2 = new TableLayoutPanel();
            buttonSave = new Button();
            label6 = new Label();
            comboBoxDelete = new ComboBox();
            btnDeleteFood = new Button();
            tableLayoutPanel3 = new TableLayoutPanel();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top;
            tableLayoutPanel1.BackColor = Color.Cornsilk;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 21.5384617F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 78.46154F));
            tableLayoutPanel1.Controls.Add(txtFood, 1, 0);
            tableLayoutPanel1.Controls.Add(txtSolution, 1, 4);
            tableLayoutPanel1.Controls.Add(label5, 0, 4);
            tableLayoutPanel1.Controls.Add(label4, 0, 3);
            tableLayoutPanel1.Controls.Add(label2, 0, 1);
            tableLayoutPanel1.Controls.Add(txtConflict, 1, 2);
            tableLayoutPanel1.Controls.Add(txtAdvantage, 1, 1);
            tableLayoutPanel1.Controls.Add(label3, 0, 2);
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Controls.Add(txtConsequence, 1, 3);
            tableLayoutPanel1.Font = new Font("標楷體", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tableLayoutPanel1.Location = new Point(140, 118);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 5;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 18F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 18F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 18F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 18F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 28F));
            tableLayoutPanel1.Size = new Size(715, 360);
            tableLayoutPanel1.TabIndex = 14;
            // 
            // txtFood
            // 
            txtFood.Anchor = AnchorStyles.None;
            txtFood.Font = new Font("標楷體", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtFood.Location = new Point(164, 12);
            txtFood.Margin = new Padding(10);
            txtFood.Name = "txtFood";
            txtFood.Size = new Size(541, 40);
            txtFood.TabIndex = 5;
            // 
            // txtSolution
            // 
            txtSolution.Anchor = AnchorStyles.None;
            txtSolution.Font = new Font("標楷體", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtSolution.Location = new Point(164, 267);
            txtSolution.Margin = new Padding(10);
            txtSolution.Multiline = true;
            txtSolution.Name = "txtSolution";
            txtSolution.ScrollBars = ScrollBars.Vertical;
            txtSolution.Size = new Size(541, 82);
            txtSolution.TabIndex = 9;
            // 
            // label5
            // 
            label5.Dock = DockStyle.Fill;
            label5.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label5.Location = new Point(3, 256);
            label5.Name = "label5";
            label5.Size = new Size(148, 104);
            label5.TabIndex = 4;
            label5.Text = "解決辦法:";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            label4.Dock = DockStyle.Fill;
            label4.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label4.Location = new Point(3, 192);
            label4.Name = "label4";
            label4.Size = new Size(148, 64);
            label4.TabIndex = 3;
            label4.Text = "後果:";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.Dock = DockStyle.Fill;
            label2.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label2.Location = new Point(3, 64);
            label2.Name = "label2";
            label2.Size = new Size(148, 64);
            label2.TabIndex = 1;
            label2.Text = "優點:";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txtConflict
            // 
            txtConflict.Anchor = AnchorStyles.None;
            txtConflict.Font = new Font("標楷體", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtConflict.Location = new Point(164, 140);
            txtConflict.Margin = new Padding(10);
            txtConflict.Name = "txtConflict";
            txtConflict.Size = new Size(541, 40);
            txtConflict.TabIndex = 7;
            // 
            // txtAdvantage
            // 
            txtAdvantage.Anchor = AnchorStyles.None;
            txtAdvantage.Font = new Font("標楷體", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtAdvantage.Location = new Point(164, 76);
            txtAdvantage.Margin = new Padding(10);
            txtAdvantage.Name = "txtAdvantage";
            txtAdvantage.Size = new Size(541, 40);
            txtAdvantage.TabIndex = 6;
            // 
            // label3
            // 
            label3.Dock = DockStyle.Fill;
            label3.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label3.Location = new Point(3, 128);
            label3.Name = "label3";
            label3.RightToLeft = RightToLeft.No;
            label3.Size = new Size(148, 64);
            label3.TabIndex = 2;
            label3.Text = "相剋:";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            label1.Dock = DockStyle.Fill;
            label1.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label1.Location = new Point(3, 0);
            label1.Name = "label1";
            label1.Size = new Size(148, 64);
            label1.TabIndex = 0;
            label1.Text = "食物:";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txtConsequence
            // 
            txtConsequence.Anchor = AnchorStyles.None;
            txtConsequence.Font = new Font("標楷體", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtConsequence.Location = new Point(164, 205);
            txtConsequence.Margin = new Padding(10);
            txtConsequence.Multiline = true;
            txtConsequence.Name = "txtConsequence";
            txtConsequence.ScrollBars = ScrollBars.Vertical;
            txtConsequence.Size = new Size(541, 37);
            txtConsequence.TabIndex = 8;
            // 
            // buttonBack
            // 
            buttonBack.Dock = DockStyle.Fill;
            buttonBack.Image = Properties.Resources.icons8_return_48;
            buttonBack.Location = new Point(3, 3);
            buttonBack.Name = "buttonBack";
            buttonBack.Size = new Size(351, 59);
            buttonBack.TabIndex = 12;
            buttonBack.UseVisualStyleBackColor = true;
            buttonBack.Click += buttonBack_Click;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Controls.Add(buttonSave, 1, 0);
            tableLayoutPanel2.Controls.Add(buttonBack, 0, 0);
            tableLayoutPanel2.Location = new Point(140, 484);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Size = new Size(715, 65);
            tableLayoutPanel2.TabIndex = 15;
            // 
            // buttonSave
            // 
            buttonSave.Dock = DockStyle.Fill;
            buttonSave.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonSave.Image = Properties.Resources.icons8_save_48;
            buttonSave.Location = new Point(360, 3);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(352, 59);
            buttonSave.TabIndex = 16;
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("標楷體", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(390, 52);
            label6.Name = "label6";
            label6.Size = new Size(237, 35);
            label6.TabIndex = 16;
            label6.Text = "更新食物資料";
            // 
            // comboBoxDelete
            // 
            comboBoxDelete.Dock = DockStyle.Fill;
            comboBoxDelete.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBoxDelete.FormattingEnabled = true;
            comboBoxDelete.Location = new Point(3, 3);
            comboBoxDelete.Name = "comboBoxDelete";
            comboBoxDelete.Size = new Size(131, 24);
            comboBoxDelete.TabIndex = 17;
            // 
            // btnDeleteFood
            // 
            btnDeleteFood.Dock = DockStyle.Fill;
            btnDeleteFood.Image = (Image)resources.GetObject("btnDeleteFood.Image");
            btnDeleteFood.Location = new Point(140, 3);
            btnDeleteFood.Name = "btnDeleteFood";
            btnDeleteFood.Size = new Size(40, 29);
            btnDeleteFood.TabIndex = 18;
            btnDeleteFood.UseVisualStyleBackColor = true;
            btnDeleteFood.Click += btnDeleteFood_Click;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 2;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 74.86339F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25.1366119F));
            tableLayoutPanel3.Controls.Add(comboBoxDelete, 0, 0);
            tableLayoutPanel3.Controls.Add(btnDeleteFood, 1, 0);
            tableLayoutPanel3.Location = new Point(672, 77);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 1;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.Size = new Size(183, 35);
            tableLayoutPanel3.TabIndex = 19;
            // 
            // ProvideForm
            // 
            AutoScaleDimensions = new SizeF(6F, 13F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(984, 561);
            Controls.Add(tableLayoutPanel3);
            Controls.Add(label6);
            Controls.Add(tableLayoutPanel2);
            Controls.Add(tableLayoutPanel1);
            Font = new Font("Microsoft Sans Serif", 8.25F);
            Name = "ProvideForm";
            Text = "提供資料";
            Load += ProvideForm_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel3.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TableLayoutPanel tableLayoutPanel1;
        private TextBox txtFood;
        private TextBox txtSolution;
        private Label label1;
        private TextBox txtConsequence;
        private Label label5;
        private Label label4;
        private Label label2;
        private TextBox txtConflict;
        private TextBox txtAdvantage;
        private Label label3;
        private Button buttonBack;
        private TableLayoutPanel tableLayoutPanel2;
        private Button buttonSave;
        private Label label6;
        private ComboBox comboBoxDelete;
        private Button btnDeleteFood;
        private TableLayoutPanel tableLayoutPanel3;
    }
}