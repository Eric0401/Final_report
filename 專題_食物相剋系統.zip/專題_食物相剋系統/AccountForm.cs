﻿namespace 專題_食物相剋系統
{
    public partial class AccountForm : Form
    {
        private string selectedFoodName = null;                // 當前選擇的食物名稱
        private readonly FormResizer resizer = new FormResizer();
        private readonly string accountName;

        // 儲存按鈕原始文字（滑鼠移入/出還原用）
        private readonly Dictionary<Button, string> originalButtonTexts = new();

        // 食物圖片快取，避免重複讀取檔案
        private readonly Dictionary<string, Image> imageCache = new();

        // 預設不可刪除的按鈕名稱集合
        private static readonly HashSet<string> defaultFoodButtons = new()
        {
            "蘋果", "豬血", "海帶", "橘子", "牛奶", "香蕉", "胡蘿蔔",
            "馬鈴薯", "黃瓜", "蕃茄", "大蔥", "蜂蜜", "大蒜", "菠菜", "黃豆"
        };

        public AccountForm(string account)
        {
            InitializeComponent();
            this.Load += AccountForm_Load;
            this.Resize += AccountForm_Resize;
            accountName = account;
        }

        // 預設建構子指向訪客
        protected AccountForm() : this("訪客") { }

        // 表單載入，綁定按鈕事件與初始化
        protected virtual void AccountForm_Load(object sender, EventArgs e)
        {
            resizer.CaptureOriginal(this);
            labelAccount.Text = "帳號： " + accountName;

            foreach (Control ctrl in tableLayoutPanelFood.Controls)
            {
                if (ctrl is Button btn && btn.Name.StartsWith("btn"))
                {
                    originalButtonTexts[btn] = btn.Text;
                    btn.Click += FoodButton_Click;
                    btn.MouseEnter += FoodButton_MouseEnter;
                    btn.MouseLeave += FoodButton_MouseLeave;
                }
            }
            // 自動補上缺少的食物按鈕
            var existingNames = tableLayoutPanelFood.Controls
                .OfType<Button>()
                .Select(b => originalButtonTexts.ContainsKey(b) ? originalButtonTexts[b] : b.Text)
                .ToHashSet();

            foreach (var foodName in Form1.foodInfo.Keys)
            {
                if (!existingNames.Contains(foodName))
                {
                    AddFoodButtonAtFront(foodName);
                }
            }
        }

        // 表單縮放事件，使用自訂縮放器
        private void AccountForm_Resize(object sender, EventArgs e) => resizer.ResizeAll(this);

        // 登出事件，顯示主視窗並關閉當前表單
        protected virtual void btnsignout_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["Form1"] is Form1 mainForm) mainForm.Show();
            Close();
        }

        // 食物按鈕點擊：顯示該食物詳細資訊
        protected virtual void FoodButton_Click(object sender, EventArgs e)
        {
            if (sender is not Button btn || !originalButtonTexts.ContainsKey(btn)) return;

            selectedFoodName = originalButtonTexts[btn];
            txtList.Clear();

            if (Form1.foodInfo.TryGetValue(selectedFoodName, out var data))
            {
                txtList.AppendText($"食物：{selectedFoodName}\r\n");
                txtList.AppendText($"優點：{string.Join("、", data.優點)}\r\n");
                txtList.AppendText($"相剋：{string.Join("、", data.相剋)}\r\n");
                txtList.AppendText($"後果：{data.後果}\r\n");
                txtList.AppendText($"解決辦法：{data.解決辦法}\r\n");
            }
            else
            {
                txtList.AppendText("查無資料");
            }
        }

        // 關鍵字查詢食物
        protected virtual void buttonSearch_Click(object sender, EventArgs e)
        {
            string keyword = textBox1.Text.Trim();
            txtList.Clear();

            if (string.IsNullOrEmpty(keyword))
            {
                txtList.AppendText("請輸入食物名稱");
                return;
            }

            if (Form1.foodInfo.TryGetValue(keyword, out var data))
            {
                txtList.AppendText($"食物：{keyword}\r\n");
                txtList.AppendText($"優點：{string.Join("、", data.優點)}\r\n");
                txtList.AppendText($"相剋：{string.Join("、", data.相剋)}\r\n");
                txtList.AppendText($"後果：{data.後果}\r\n");
                txtList.AppendText($"解決辦法：{data.解決辦法}\r\n");
                selectedFoodName = keyword;
            }
            else
            {
                txtList.AppendText("查無此食物，請自行新增");
                selectedFoodName = null;
            }
        }

        // 按下 Enter 鍵時觸發查詢
        protected virtual void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                buttonSearch.PerformClick();
                e.SuppressKeyPress = true;
            }
        }

        // 新增食物資料（打開 ProvideForm）
        protected virtual void buttonProvide_Click(object sender, EventArgs e)
        {
            new ProvideForm().Show();
            this.Hide();
        }

        // 飲食紀錄（打開 FoodLogForm）
        protected virtual void buttonEat_Click(object sender, EventArgs e)
        {
            new FoodLogForm(accountName).Show();
            this.Hide();
        }


        // 滑鼠移入食物按鈕時載入圖片並隱藏文字
        private void FoodButton_MouseEnter(object sender, EventArgs e)
        {
            if (sender is not Button btn || !originalButtonTexts.ContainsKey(btn)) return;

            string foodName = originalButtonTexts[btn];
            string imagePath = $"Resources\\{foodName}.jpg";

            if (!imageCache.ContainsKey(foodName) && File.Exists(imagePath))
            {
                using var fs = new FileStream(imagePath, FileMode.Open, FileAccess.Read);
                imageCache[foodName] = new Bitmap(fs);
            }

            if (imageCache.ContainsKey(foodName))
            {
                btn.BackgroundImage = imageCache[foodName];
                btn.BackgroundImageLayout = ImageLayout.Zoom;
                btn.Text = "";
            }
        }

        // 滑鼠移出按鈕還原文字與移除圖片
        private void FoodButton_MouseLeave(object sender, EventArgs e)
        {
            if (sender is not Button btn || !originalButtonTexts.ContainsKey(btn)) return;

            btn.BackgroundImage = null;
            btn.Text = originalButtonTexts[btn];
        }

        // 自訂繪製 GroupBox 邊框，去虛線
        protected virtual void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = (GroupBox)sender;
            e.Graphics.Clear(box.BackColor);
            using var borderPen = new Pen(Color.Black, 1);
            e.Graphics.DrawRectangle(borderPen, 0, 0, box.Width - 1, box.Height - 1);
        }

        // 關閉表單時釋放圖片資源
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            foreach (var img in imageCache.Values) img.Dispose();
            imageCache.Clear();

            base.OnFormClosed(e);
        }

        // 新增食物按鈕並插入首位
        public void AddFoodButtonAtFront(string foodName)
        {
            var newBtn = new Button
            {
                Text = foodName,
                Font = new Font("標楷體", 12F, FontStyle.Regular),
                Size = new Size(75, 75),
                Anchor = AnchorStyles.None,
                UseVisualStyleBackColor = true
            };

            // 綁定事件
            newBtn.Click += FoodButton_Click;
            newBtn.MouseEnter += FoodButton_MouseEnter;
            newBtn.MouseLeave += FoodButton_MouseLeave;

            // 現有控制項依序後移
            for (int i = tableLayoutPanelFood.Controls.Count - 1; i >= 0; i--)
            {
                var ctrl = tableLayoutPanelFood.Controls[i];
                int col = tableLayoutPanelFood.GetColumn(ctrl);
                int row = tableLayoutPanelFood.GetRow(ctrl);

                int index = row * tableLayoutPanelFood.ColumnCount + col + 1;
                int newRow = index / tableLayoutPanelFood.ColumnCount;
                int newCol = index % tableLayoutPanelFood.ColumnCount;

                tableLayoutPanelFood.SetRow(ctrl, newRow);
                tableLayoutPanelFood.SetColumn(ctrl, newCol);
            }

            tableLayoutPanelFood.Controls.Add(newBtn, 0, 0);

            // 調整行數與 RowStyle
            int totalButtons = tableLayoutPanelFood.Controls.Count;
            int neededRows = (int)Math.Ceiling(totalButtons / (double)tableLayoutPanelFood.ColumnCount);
            if (neededRows > tableLayoutPanelFood.RowCount)
            {
                tableLayoutPanelFood.RowCount = neededRows;
                for (int i = tableLayoutPanelFood.RowStyles.Count; i < neededRows; i++)
                {
                    tableLayoutPanelFood.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / neededRows));
                }
            }

            originalButtonTexts[newBtn] = foodName;
            resizer.CaptureOriginalControl(newBtn);
        }

        // 移除食物按鈕（非預設按鈕）
        public void RemoveFoodButton(string foodName)
        {
            if (defaultFoodButtons.Contains(foodName)) return;

            var btnToRemove = tableLayoutPanelFood.Controls.OfType<Button>().FirstOrDefault(b => b.Text == foodName);
            if (btnToRemove == null) return;

            tableLayoutPanelFood.Controls.Remove(btnToRemove);
            originalButtonTexts.Remove(btnToRemove);
            btnToRemove.Dispose();

            RefreshFoodButtonsLayout();
        }

        // 重新排版按鈕（依 TabIndex）
        public void RefreshFoodButtonsLayout()
        {
            var buttons = tableLayoutPanelFood.Controls.OfType<Button>()
                .OrderBy(btn => btn.TabIndex)
                .ToList();

            tableLayoutPanelFood.Controls.Clear();

            int colCount = tableLayoutPanelFood.ColumnCount;
            int row = 0;
            int col = 0;

            foreach (var btn in buttons)
            {
                tableLayoutPanelFood.Controls.Add(btn, col, row);
                if (++col >= colCount)
                {
                    col = 0;
                    row++;
                }
            }

            tableLayoutPanelFood.RowCount = row + 1;
        }

        // 寄送 Email 按鈕事件
        private void btnSendEmail_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(selectedFoodName))
            {
                new EmailForm(selectedFoodName).ShowDialog();
            }
            else
            {
                MessageBox.Show("請先查詢並選擇一項食物。");
            }
        }
    }
}
